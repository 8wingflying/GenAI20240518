API_KEY = "sk-proj-tC1Wabr5YyyBya1l8xqQT3BlbkFJ2ebXBIFzov6h3fwq4fnr"
